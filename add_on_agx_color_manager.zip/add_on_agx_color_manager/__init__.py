bl_info = {
    "name": "AgX Color Manager",
    "author": "Dimona Patrick",
    "version": (1, 0, 1),
    "blender": (4, 2, 0),
    "location": "Properties > Render > AgX Color Manager",
    "description": "Professional AgX color management system",
    "warning": "",
    "doc_url": "https://github.com/Dream-Pixels-Forge/add_on_agx_color_manager",
    "category": "Render",
}

import bpy
import os
from bpy.types import Panel, Operator, PropertyGroup, AddonPreferences
from bpy.props import (
    StringProperty, 
    BoolProperty, 
    FloatProperty, 
    FloatVectorProperty,
    EnumProperty,
    PointerProperty
)
from pathlib import Path
import tempfile
from bpy.app.handlers import persistent
import json




class AgXLogger:
    """Enhanced logging system with debug levels"""
    
    def __init__(self):
        self.log_file = os.path.join(tempfile.gettempdir(), "agx_color_manager.log")
        self.debug_mode = False
    
    def set_debug_mode(self, enabled: bool):
        """Enable or disable debug mode"""
        self.debug_mode = enabled
    
    def log(self, message: str, level: str = "INFO"):
        """Log a message with timestamp and optional debug info"""
        from datetime import datetime
        
        if not self.debug_mode and level == "DEBUG":
            return
            
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] [{level}] {message}\n"
        
        try:
            with open(self.log_file, 'a') as f:
                f.write(log_entry)
            
            if level in ["ERROR", "WARNING"] or self.debug_mode:
                print(f"AgX: {message}")
                
        except Exception as e:
            print(f"Logging failed: {str(e)}")
    
    def clear_log(self):
        """Clear the log file"""
        if os.path.exists(self.log_file):
            try:
                os.remove(self.log_file)
            except Exception as e:
                print(f"Failed to clear log: {str(e)}")

class AgXPreferences(AddonPreferences):
    bl_idname = __name__

    auto_setup: BoolProperty(
        name="Auto Setup",
        description="Automatically setup AgX on file load",
        default=True
    )
    
    debug_mode: BoolProperty(
        name="Debug Mode",
        description="Enable detailed logging for troubleshooting",
        default=False,
        update=lambda self, context: self._update_debug_mode(context)
    )
    
    default_look: EnumProperty(
        name="Default Look",
        description="Default AgX look to apply",
        items=[
            ('NONE', "None", "No look modification"),
            ('MEDIUM', "Medium Contrast", "Standard contrast look"),
            ('HIGH', "High Contrast", "Higher contrast look"),
            ('CUSTOM', "Custom", "Custom look settings")
        ],
        default='MEDIUM'
    )
    
    def _update_debug_mode(self, context):
        AgXLogger().set_debug_mode(self.debug_mode)
    
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "auto_setup")
        layout.prop(self, "debug_mode")
        layout.prop(self, "default_look")

class AgXTextureProfile:
    """Improved texture profile configuration"""
    
    COLOR_TEXTURES = {
        'basecolor', 'diffuse', 'albedo', 'color', 'base_color',
        'diff', 'paint', 'emission', 'emissive', 'base', 'texture'
    }
    
    NON_COLOR_TEXTURES = {
        'normal', 'bump', 'roughness', 'metallic', 'specular',
        'glossiness', 'height', 'displacement', 'ambient_occlusion',
        'ao', 'metalness', 'opacity', 'alpha', 'mask'
    }
    
    HDR_FORMATS = {'.exr', '.hdr'}
    
    @classmethod
    def get_texture_type(cls, filename: str) -> str:
        """Determine texture type from filename"""
        name_lower = filename.lower()
        ext = os.path.splitext(name_lower)[1]
        
        if ext in cls.HDR_FORMATS:
            return 'hdr'
            
        for color_term in cls.COLOR_TEXTURES:
            if color_term in name_lower:
                return 'color'
                
        for non_color_term in cls.NON_COLOR_TEXTURES:
            if non_color_term in name_lower:
                return 'non-color'
                
        return 'color'

class AgXColorManager:
    """Core color management system"""
    
    def __init__(self):
        self.logger = AgXLogger()
        self.texture_profile = AgXTextureProfile()
        self.processed_textures = set()
    
    def setup_color_management(self, context):
        """Configure AgX color management"""
        try:
            scene = context.scene
            
            # Basic settings
            scene.view_settings.use_curve_mapping = False
            scene.view_settings.exposure = 0
            scene.view_settings.gamma = 1
            
            # AgX specific settings
            scene.view_settings.view_transform = 'AgX'
            scene.view_settings.look = self._get_default_look(context)
            scene.display_settings.display_device = 'sRGB'
            
            self.logger.log("AgX color management configured successfully")
            return True
            
        except Exception as e:
            self.logger.log(f"Color management setup failed: {str(e)}", "ERROR")
            return False
    
    def _get_default_look(self, context) -> str:
        """Get default look based on preferences"""
        prefs = context.preferences.addons[__name__].preferences
        look_map = {
            'AGX_PUNCHY': 'AgX - Punchy',
            'AGX_BASE': 'AgX - Base Contrast',
            'AGX_HIGH': 'AgX - High Contrast',
            'AGX_MED_HIGH': 'AgX - Medium High Contrast',
            'AGX_MED_LOW': 'AgX - Medium Low Contrast',
            'AGX_LOW': 'AgX - Low Contrast'
        }
        return look_map.get(prefs.default_look, 'AgX - Medium High Contrast')
    
    def process_textures(self):
        """Process all textures in the scene"""
        try:
            for image in bpy.data.images:
                if image.source == 'FILE' and image not in self.processed_textures:
                    self._process_single_texture(image)
                    self.processed_textures.add(image)
                    
            self.logger.log("Texture processing completed")
            return True
            
        except Exception as e:
            self.logger.log(f"Texture processing failed: {str(e)}", "ERROR")
            return False
    
    def _process_single_texture(self, image):
        """Process a single texture"""
        texture_type = self.texture_profile.get_texture_type(image.name)
        colorspace_map = {
            'color': 'sRGB',
            'non-color': 'Non-Color',
            'hdr': 'Linear'
        }
        
        try:
            image.colorspace_settings.name = colorspace_map.get(texture_type, 'sRGB')
            self.logger.log(f"Set {image.name} colorspace to {image.colorspace_settings.name}", "DEBUG")
        except Exception as e:
            self.logger.log(f"Failed to process texture {image.name}: {str(e)}", "ERROR")
            raise

class AgXRenderSettings(PropertyGroup):
    """Enhanced render settings for AgX workflow"""
    
    exposure_compensation: FloatProperty(
        name="Exposure",
        description="Global exposure compensation",
        default=0.0,
        min=-5.0,
        max=5.0,
        step=0.1,
        update=lambda self, context: self._update_exposure(context)
    )
    
    contrast: FloatProperty(
        name="Contrast",
        description="Global contrast adjustment",
        default=1.0,
        min=0.0,
        max=2.0,
        step=0.05
    )
    
    saturation: FloatProperty(
        name="Saturation",
        description="Global saturation adjustment",
        default=1.0,
        min=0.0,
        max=2.0,
        step=0.05
    )
    
    highlight_recovery: FloatProperty(
        name="Highlight Recovery",
        description="Recover detail in highlights",
        default=1.0,
        min=0.0,
        max=2.0,
        step=0.05
    )
    
    shadow_recovery: FloatProperty(
        name="Shadow Recovery",
        description="Recover detail in shadows",
        default=0.0,
        min=-1.0,
        max=1.0,
        step=0.05
    )
    
    use_false_color: BoolProperty(
        name="False Color",
        description="Enable false color display for exposure checking",
        default=False
    )
    
    color_tint: FloatVectorProperty(
        name="Color Tint",
        description="Global color tint adjustment",
        default=(1.0, 1.0, 1.0),
        min=0.0,
        max=2.0,
        size=3,
        subtype='COLOR'
    )
    
    def _update_exposure(self, context):
        context.scene.view_settings.exposure = self.exposure_compensation

class AGX_PT_main_panel(Panel):
    bl_label = "AgX Color Manager"
    bl_idname = "AGX_PT_main_panel"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "render"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        settings = context.scene.agx_render_settings

        # Status and Setup
        box = layout.box()
        row = box.row()
        row.label(text="Color Management", icon='COLOR')
        row = box.row()
        row.label(text=f"View Transform: {context.scene.view_settings.view_transform}")
        
        # Quick Actions
        row = box.row(align=True)
        row.operator("agx.quick_setup", text="Setup AgX", icon='CHECKMARK')
        row.operator("agx.restore_defaults", text="Defaults", icon='LOOP_BACK')
        
        # Main Settings
        box = layout.box()
        box.label(text="Image Settings", icon='IMAGE_DATA')
        col = box.column(align=True)
        col.prop(settings, "exposure_compensation", slider=True)
        col.prop(settings, "contrast", slider=True)
        col.prop(settings, "saturation", slider=True)
        
        # Recovery Settings
        box = layout.box()
        box.label(text="Recovery", icon='MODIFIER')
        col = box.column(align=True)
        col.prop(settings, "highlight_recovery", slider=True)
        col.prop(settings, "shadow_recovery", slider=True)
        
        # Color Tint
        box = layout.box()
        box.label(text="Color Tint", icon='COLOR')
        box.prop(settings, "color_tint")
        
        # Display Options
        box = layout.box()
        box.label(text="Display", icon='RESTRICT_VIEW_OFF')
        box.prop(settings, "use_false_color")

class AGX_OT_quick_setup(Operator):
    bl_idname = "agx.quick_setup"
    bl_label = "Quick Setup AgX"
    bl_description = "Configure AgX color management"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        color_manager = AgXColorManager()
        
        if not color_manager.setup_color_management(context):
            self.report({'ERROR'}, "Failed to setup color management")
            return {'CANCELLED'}
            
        if not color_manager.process_textures():
            self.report({'ERROR'}, "Failed to process textures")
            return {'CANCELLED'}
            
        self.report({'INFO'}, "AgX color management setup completed")
        return {'FINISHED'}

class AGX_OT_restore_defaults(Operator):
    bl_idname = "agx.restore_defaults"
    bl_label = "Restore Defaults"
    bl_description = "Restore default color management settings"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        try:
            settings = context.scene.agx_render_settings
            
            # Reset all settings to defaults
            for prop in settings.__annotations__.keys():
                if hasattr(settings.__annotations__[prop], "default"):
                    setattr(settings, prop, settings.__annotations__[prop].default)
            
            self.report({'INFO'}, "Settings restored to defaults")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to restore defaults: {str(e)}")
            return {'CANCELLED'}

@persistent
def load_post_handler(dummy):
    """Handler that runs after loading a blend file"""
    try:
        if bpy.context.preferences.addons[__name__].preferences.auto_setup:
            bpy.ops.agx.quick_setup()
    except Exception as e:
        print(f"Error in load_post_handler: {str(e)}")

classes = (
    AgXPreferences,
    AgXRenderSettings,
    AGX_PT_main_panel,
    AGX_OT_quick_setup,
    AGX_OT_restore_defaults,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    bpy.types.Scene.agx_render_settings = PointerProperty(type=AgXRenderSettings)
    bpy.app.handlers.load_post.append(load_post_handler)

def unregister():
    bpy.app.handlers.load_post.remove(load_post_handler)
    del bpy.types.Scene.agx_render_settings
    
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
